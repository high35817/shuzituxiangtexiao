function t = lut_256
%256ɫ��ɫ��
 
i = 0:255;

t = [0 0;255 255;256 256];
t = interp1q(t(:,1),t(:,2),i');

t = round(t);
t = max(0, t);
t = min(255, t);